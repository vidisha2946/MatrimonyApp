import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart'; // Import the url_launcher package

class ProfilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profile Page'),
        backgroundColor: Colors.pinkAccent.shade100,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              ProfileHeader(),
              AboutMe(),
              SocialLinks(),
              ContactInfo(),
            ],
          ),
        ),
      ),
    );
  }
}

class ProfileHeader extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        CircleAvatar(
          radius: 75,
          backgroundImage: AssetImage('assets/images/profile.jpg'), // Add your image path
        ),
        SizedBox(height: 10),
        Text(
          'Vidisha Bhagiya',
          style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
        ),
        Text(
          'Developer | Tech Enthusiast',
          style: TextStyle(fontSize: 16, color: Colors.grey),
        ),
        SizedBox(height: 20),
      ],
    );
  }
}

class AboutMe extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          'About Me',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        SizedBox(height: 10),
        Text(
          'I am a passionate software developer with experience in creating web and mobile applications. '
              'I love to learn new technologies and solve complex problems.',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 16, color: Colors.black54),
        ),
        SizedBox(height: 20),
      ],
    );
  }
}

class SocialLinks extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          'Connect with me',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SocialLinkButton(
              text: 'LinkedIn',
              url: 'https://www.linkedin.com/in/vidisha-bhagiya-6144522a5/',
              color: Colors.blue,
            ),
            SizedBox(width: 15),
            SocialLinkButton(
              text: 'GitHub',
              url: 'https://github.com/vidisha2946',
              color: Colors.black,
            ),
            SizedBox(width: 15),
            SocialLinkButton(
              text: 'LeetCode',
              url: 'https://leetcode.com/u/vidisha2946/',
              color: Colors.yellow.shade700,
            ),
          ],
        ),
        SizedBox(height: 20),
      ],
    );
  }
}

class SocialLinkButton extends StatelessWidget {
  final String text;
  final String url;
  final Color color;

  SocialLinkButton({required this.text, required this.url, required this.color});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: () async {
        // Launch the URL in the browser
        if (await canLaunch(url)) {
          await launch(url); // Open the URL in the browser
        } else {
          throw 'Could not launch $url'; // Error handling
        }
      },
      style: ButtonStyle(
        backgroundColor: MaterialStateProperty.all(color),
        padding: MaterialStateProperty.all(EdgeInsets.symmetric(horizontal: 15, vertical: 10)),
        shape: MaterialStateProperty.all(RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))),
      ),
      child: Text(text, style: TextStyle(color: Colors.white)),
    );
  }
}

class ContactInfo extends StatelessWidget {
  // Helper function to launch URL
  Future<void> _launchURL(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          'Contact Info',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        SizedBox(height: 10),
        ListView(
          shrinkWrap: true,
          children: [
            // Email
            ListTile(
              leading: Icon(Icons.email, color: Colors.pinkAccent.shade100),
              title: GestureDetector(
                onTap: () => _launchURL('mailto:vidishabhagiya29@gmail.com'),
                child: Text(
                  'vidishabhagiya29@gmail.com',
                  style: TextStyle(fontSize: 16, color: Colors.blueAccent, decoration: TextDecoration.underline),
                ),
              ),
              trailing: IconButton(
                icon: Icon(Icons.copy),
                onPressed: () {
                  // Copy to clipboard
                },
              ),
            ),
            Divider(),
            // Location
            ListTile(
              leading: Icon(Icons.location_on, color: Colors.pinkAccent.shade100),
              title: Text(
                'Darshan University , Gujarat , INDIA',
                style: TextStyle(fontSize: 16),
              ),
              trailing: IconButton(
                icon: Icon(Icons.map),
                onPressed: () {
                  // Open map (assume location URL or map app)
                  _launchURL('https://www.google.com/maps/place/Darshan+University/@22.4306537,70.7821394,17z/data=!3m1!4b1!4m6!3m5!1s0x3959c7a3ba783351:0x28dc6eea8324e9d2!8m2!3d22.4306537!4d70.7847143!16s%2Fg%2F1tj5jk0c?entry=ttu&g_ep=EgoyMDI1MDEyOS4xIKXMDSoASAFQAw%3D%3D');
                },
              ),
            ),
            Divider(),
          ],
        ),
      ],
    );
  }
}
