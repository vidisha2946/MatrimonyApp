import 'package:flutter/material.dart';

class UserDetailPage extends StatefulWidget {
  final Map<String, dynamic> user;

  const UserDetailPage({super.key, required this.user});

  @override
  _UserDetailPageState createState() => _UserDetailPageState();
}

class _UserDetailPageState extends State<UserDetailPage> {
  bool _obscurePassword = true;

  int _calculateAge(String dob) {
    final dobDate = DateTime.tryParse(dob.split('/').reversed.join('-'));
    if (dobDate == null) return 0;
    final today = DateTime.now();
    int age = today.year - dobDate.year;
    if (today.month < dobDate.month || (today.month == dobDate.month && today.day < dobDate.day)) {
      age--;
    }
    return age;
  }

  @override
  Widget build(BuildContext context) {
    final age = _calculateAge(widget.user['dob']);

    return Scaffold(
      appBar: AppBar(
        title: const Text("User Details"),
        backgroundColor: Colors.pinkAccent.shade100,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Card(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          elevation: 4,
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: CircleAvatar(
                    radius: 40,
                    backgroundColor: Colors.pinkAccent.shade100,
                    child: Text(
                      widget.user['name'][0].toUpperCase(),
                      style: const TextStyle(fontSize: 24, color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                _buildDetailRow("Full Name", widget.user['name']),
                _buildDetailRow("Email", widget.user['email']),
                _buildDetailRow("Mobile Number", widget.user['mobile']),
                _buildDetailRow("Date of Birth", widget.user['dob']),
                _buildDetailRow("Age", "$age years"),
                _buildDetailRow("City", widget.user['city']),
                _buildDetailRow("Gender", widget.user['gender']),
                _buildDetailRow("Hobbies", widget.user['hobbies']),
                _buildPasswordRow("Password", widget.user['password']),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(String title, String? value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "$title: ",
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
          ),
          Expanded(
            child: Text(
              value ?? "Not provided",
              style: const TextStyle(fontSize: 16),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPasswordRow(String title, String? value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          Text(
            "$title: ",
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
          ),
          Expanded(
            child: Text(
              _obscurePassword ? "********" : value ?? "Not provided",
              style: const TextStyle(fontSize: 16),
            ),
          ),
          IconButton(
            icon: Icon(
              _obscurePassword ? Icons.visibility : Icons.visibility_off,
              color: Colors.pinkAccent.shade100,
            ),
            onPressed: () {
              setState(() {
                _obscurePassword = !_obscurePassword;
              });
            },
          ),
        ],
      ),
    );
  }
}
